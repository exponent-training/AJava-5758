package com.Service;

public interface PersonAdharService {

	public void addPersonWithAdhar();

	public void getPersonOnly();

	public void getAdharOnly();

	public void getallData();

	public void updatePersonDetailonlyUsingPID();

	public void updateAdharDetailOnlyUsingPID();

	public void DeletePersonOnlyUsingPID();

	public void DeleteAdharOnlyUsingPID();

}
