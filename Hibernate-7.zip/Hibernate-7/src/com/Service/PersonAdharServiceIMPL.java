package com.Service;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.Config.Hibernatutil;
import com.Entity.Adhar;
import com.Entity.Person;

public class PersonAdharServiceIMPL implements PersonAdharService {

	SessionFactory sf = Hibernatutil.getsessionFactory();

	@Override
	public void addPersonWithAdhar() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		Person p = new Person();
		System.out.println("Enter the Person name");
		p.setPname(sc.next());
		System.out.println("Enter the Person Address :- ");
		p.setPaddress(sc.next());

		Adhar adhar = new Adhar();
		System.out.println("Enter the AdharNumebr :- ");
		adhar.setAdharNumber(sc.next());

		p.setAdhar(adhar);

		s.save(p);
		s.beginTransaction().commit();
		System.out.println("Person Added");

	}

	@Override
	public void getPersonOnly() {
		// HW

	}

	@Override
	public void getAdharOnly() {
		// HW

	}

	@Override
	public void getallData() {

		Session s = sf.openSession();
		Query query = s.createQuery("From Person");
		List<Person> resultList = query.getResultList();
		for (Person person : resultList) {
			System.out.println(person);
		}

	}

	@Override
	public void updatePersonDetailonlyUsingPID() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Person ID :- ");
		Person person = s.get(Person.class, sc.nextInt());
		if (person != null) {
			System.out.println("Enter the New Person Name :- ");
			person.setPname(sc.next());
			System.out.println("Enetr the New Address :- ");
			person.setPaddress(sc.next());

			s.update(person);
			s.beginTransaction().commit();
			System.out.println("Person updated");
		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void updateAdharDetailOnlyUsingPID() {
//		HW

	}

	@Override
	public void DeletePersonOnlyUsingPID() {

		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Person ID :- ");
		Person person = s.get(Person.class, sc.nextInt());
		if (person != null) {

			person.setAdhar(null);
			s.update(person);
			s.delete(person);
			s.beginTransaction().commit();
			System.out.println("Person Deleted");

		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void DeleteAdharOnlyUsingPID() {

//		hw
		
	}

}
