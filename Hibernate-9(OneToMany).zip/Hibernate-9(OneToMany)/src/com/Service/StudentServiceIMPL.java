package com.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.Config.Hibernatutil;
import com.Entity.Student;
import com.Entity.Subject;

public class StudentServiceIMPL implements StudentServices {

	SessionFactory sf = Hibernatutil.getsessionFactory();

	@Override
	public void addStudentWithSubjects() {

		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();
		Student st = new Student();
		List<Subject> lib = new ArrayList<Subject>();
		System.out.println("Enter the Student Name ");
		st.setSname(sc.next());

		System.out.println("Enter how many subjects you want to add :- ");
		int n = sc.nextInt();
		for (int i = 1; i <= n; i++) {
			Subject subject = new Subject();
			System.out.println("Enter the Subject Name :- ");
			subject.setSubName(sc.next());

			lib.add(subject);
		}

		st.setListSub(lib);
		s.save(st);
		s.beginTransaction().commit();
		System.out.println("Student Added");

	}

	@Override
	public void getStudentOnly() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getsubjectsOnly() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateStudentDetailsUsingSID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateSpecificSubjectUsinStudentID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteStudentOnlyUsingSID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteSpecificSubjectFromSpecificStudentUsingSID() {
		Scanner sc = new Scanner(System.in);
		Session s = sf.openSession();

		System.out.println("Enter the Student ID :- ");
		Student student = s.get(Student.class, sc.nextInt());
		if (student != null) {
//			2
			List<Subject> listSub = student.getListSub();
			System.out.println("Enter the Subject ID For delettion:- ");
			int subid = sc.nextInt();
			Subject subject = null;
			for (Subject sub : listSub) {
				if (sub != null && sub.getSubId() == subid) {
//					listSub.remove(sub);
					subject = sub;

				}
			}

			listSub.remove(subject);
			student.setListSub(listSub);
			s.delete(subject);
			s.beginTransaction().commit();
			System.out.println("Subject Deleted");

		} else {
			System.out.println("Invalid ID");
		}

	}

}
