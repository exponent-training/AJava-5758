package com.Service;

public interface StudentServices {

	void addStudentWithSubjects();

	void getStudentOnly();

	void getsubjectsOnly();

	void updateStudentDetailsUsingSID();

	void updateSpecificSubjectUsinStudentID();

	void deleteStudentOnlyUsingSID();

	void deleteSpecificSubjectFromSpecificStudentUsingSID();
}
