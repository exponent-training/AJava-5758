package com.Controller;

import com.Service.StudentServiceIMPL;
import com.Service.StudentServices;

public class HomeController {

	public static void main(String[] args) {

		StudentServices sas = new StudentServiceIMPL();

//		sas.addStudentWithSubjects();
		
		sas.deleteSpecificSubjectFromSpecificStudentUsingSID();
	}

}
