package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.entity.Category;
import com.entity.Product;
import com.util.HibernateUtil;

public class ProductServiceImpl implements ProductService {

	Scanner sc = new Scanner(System.in);

	@Override
	public void addCategoryAlongWithProduct() {

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

		Session session = sessionFactory.openSession();

		System.out.println("Enter category name: ");
		Category c = new Category();
		c.setCategoryname(sc.next());

		System.out.println("enter no. of product you want add:");
		int n = sc.nextInt();

		List<Product> prodlist = new ArrayList<Product>();
		for (int i = 1; i <= n; i++) {
			Product p = new Product();
			System.out.println("Enter productname: ");
			p.setProductname(sc.next());
			prodlist.add(p);
		}
		c.setProductList(prodlist);
		session.save(c);
		session.beginTransaction().commit();
		System.out.println("success!!");
	}

	@Override
	public void getAllProductDetails() {

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

		Session session = sessionFactory.openSession();

		Query<Product> query = session.createQuery("from Product");

		List<Product> list = query.getResultList();

		System.out.println("All Product details:");

		for (Product product : list) {
			System.out.println(product);
		}
	}

	@Override
	public void deleteCategoryOnlyUsingCid() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

		Session session = sessionFactory.openSession();
		
		System.out.println("enter cid:");
		Category ct =session.get(Category.class, sc.nextInt());
		
	//	List<Product> productList = ct.getProductList();

		ct.setProductList(null);
		session.update(ct);
		session.delete(ct);
		session.beginTransaction().commit();
		System.out.println("deleted!!");
	}

	@Override
	public void deleteProductOnlyUsingCid() {
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

		Session session = sessionFactory.openSession();
		
		System.out.println("enter cid:");
		Category ct =session.get(Category.class, sc.nextInt());
		
		Product prod = null;
		
		if (ct!=null) {
			System.out.println("Enter pid:");
			int inPid= sc.nextInt(); 
			List<Product> list = ct.getProductList();
			for (Product product : list) {
				if (product!=null && inPid==product.getProdid()) {
					prod = product;
				}
			}
			list.remove(prod);
			session.update(ct);
			session.delete(prod);
			session.beginTransaction().commit();
			System.out.println("deleted!!");
		} else {

		}

	}

	@Override
	public void updateProductUsingCid() {
		// TODO Auto-generated method stub

	}

}
