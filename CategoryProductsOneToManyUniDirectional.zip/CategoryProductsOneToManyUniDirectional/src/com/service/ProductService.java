package com.service;

public interface ProductService {
	
	public void addCategoryAlongWithProduct();
	
	public void getAllProductDetails();
	
	public void deleteCategoryOnlyUsingCid();
	
	public void deleteProductOnlyUsingCid();
	
	public void updateProductUsingCid();

}
