package com.controller;

import com.service.ProductService;
import com.service.ProductServiceImpl;

public class HomeController {
	
	public static void main(String[] args) {
		 ProductService ps = new ProductServiceImpl();
		 
		// ps.addCategoryAlongWithProduct();
		// ps.getAllProductDetails();
		 
		// ps.deleteCategoryOnlyUsingCid();
		 
		 ps.deleteProductOnlyUsingCid();
	}

}
