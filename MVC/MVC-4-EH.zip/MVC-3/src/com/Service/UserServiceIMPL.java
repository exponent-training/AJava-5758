package com.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.UserDao;
import com.Entity.User;

@Service
public class UserServiceIMPL implements UserService {

	@Autowired
	private UserDao ud;
	
	@Override
	public void getUserInService(User user) {
	
		System.out.println("I am In User Service");
		
		System.out.println(user);
		
		ud.getUserInDao(user);
		
	}

}
