package com.DAO;

import com.Entity.User;

public interface UserDao {

	public void getUserInDao(User user);
}
