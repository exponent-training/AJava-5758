package com.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.User;

@Repository
public class userDAOIMPL implements UserDao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void getUserInDao(User user) {
		System.out.println("I am in DAO Layer");
		System.out.println(user);

		Session s = sf.openSession();
		s.save(user);
		s.beginTransaction().commit();
		System.out.println("User Saved");

	}
}
