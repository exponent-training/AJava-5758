package com.Exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandling {

	@ExceptionHandler(NullPointerException.class)
	public String handleNullpointer() {
		System.out.println("Global Handle");
		return "error";
	}

	@ExceptionHandler(UserNotFoundException.class)
	public String handleUserNotFoundException() {
		return "error";
	}

}
