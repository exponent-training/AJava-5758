package com.Service;

import com.Entity.User;

public interface UserService {

	public void getUserInService(User user);

}
