package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.User;
import com.Service.UserService;

@Controller
public class LoginController {

	@Autowired
	private UserService us;

	@RequestMapping("/log")
	public String loginRequest() {
		System.out.println("This is login Request");
		System.out.println("Log action is here");
		// web page Name

		return "Success";
	}

	@RequestMapping("/reg")
	public String registerRequest(@ModelAttribute User user) {
		System.out.println("This is Register Request");
		System.out.println("Reg action is here");
		// web page Name

//		System.out.println("userName is :- " + username);
//		System.out.println("Address is :- " + Address);

		System.out.println(user);

		us.getUserInService(user);

		return "Login";
	}
}
