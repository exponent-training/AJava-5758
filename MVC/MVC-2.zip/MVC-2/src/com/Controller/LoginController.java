package com.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

	@RequestMapping("/log")
	public void loginRequest() {
		System.out.println("This is login Request");
		System.out.println("Log action is here");
	}
}
