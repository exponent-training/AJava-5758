package com.Entity;

public class School {
	
	private String schoolName;
	
	private String schoolCityName;

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolCityName() {
		return schoolCityName;
	}

	public void setSchoolCityName(String schoolCityName) {
		this.schoolCityName = schoolCityName;
	}

	@Override
	public String toString() {
		return "School [schoolName=" + schoolName + ", schoolCityName=" + schoolCityName + "]";
	}
	
	

}
