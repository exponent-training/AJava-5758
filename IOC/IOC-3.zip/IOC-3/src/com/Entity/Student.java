package com.Entity;

public class Student {

	private int sid;

	private String sname;

	private String saddress;

	private School school;

	private School school1;

	/*
	 * private Department dept;
	 * 
	 * public Department getDept() { return dept; }
	 * 
	 * public void setDept(Department dept) { this.dept = dept; }
	 */

	public School getSchool1() {
		return school1;
	}

	public void setSchool1(School school1) {
		this.school1 = school1;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSaddress() {
		return saddress;
	}

	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}

	public School getSchool() {
		return school;
	}

	public void setSchool(School school) {
		this.school = school;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", saddress=" + saddress + ", school=" + school
				+ ", school1=" + school1 + "]";
	}

}
