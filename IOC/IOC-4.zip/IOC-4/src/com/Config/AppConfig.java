package com.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.Entity.School;
import com.Entity.Student;

@Configuration
@Component
public class AppConfig {

	@Bean(name = "sc1")
	@Primary
	public School setSchool1() {
		School sc = new School();
		sc.setSchoolName("PCCOE");
		return sc;
	}
	
	@Bean(name = "sc2")
	@Primary
	public School setSchool2() {
		School sc = new School();
		sc.setSchoolName("INDIRA");
		return sc;
	}

	@Bean(name = "stu")
	@Scope(value = "prototype")
	public Student setStudent() {
		Student st = new Student();
		st.setSid(101);
		st.setSname("raj");
//		st.setSchool(setSchool());

		return st;

	}

}
