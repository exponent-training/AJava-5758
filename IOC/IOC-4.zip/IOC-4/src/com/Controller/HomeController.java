package com.Controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.Config.AppConfig;
import com.Entity.Student;

public class HomeController {

	public static void main(String[] args) {

		ApplicationContext apc = new AnnotationConfigApplicationContext(AppConfig.class);
		Student stu = (Student) apc.getBean("stu");
		System.out.println(stu);

	}

}
