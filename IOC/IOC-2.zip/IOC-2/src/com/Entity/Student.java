package com.Entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Student {

//	12 fields

	private int sid;

	private String sname;

	private String saddress;

	private List<String> schoolNames = new ArrayList<String>();

	private Set<Integer> pincodes = new HashSet<Integer>();

	private Map<String, Integer> subMarks = new HashMap<String, Integer>();

	public Student(int sid, String sname, String saddress) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.saddress = saddress;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getSaddress() {
		return saddress;
	}

	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}

	public List<String> getSchoolNames() {
		return schoolNames;
	}

	public void setSchoolNames(List<String> schoolNames) {
		this.schoolNames = schoolNames;
	}

	public Set<Integer> getPincodes() {
		return pincodes;
	}

	public void setPincodes(Set<Integer> pincodes) {
		this.pincodes = pincodes;
	}

	public Map<String, Integer> getSubMarks() {
		return subMarks;
	}

	public void setSubMarks(Map<String, Integer> subMarks) {
		this.subMarks = subMarks;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", saddress=" + saddress + ", schoolNames=" + schoolNames
				+ ", pincodes=" + pincodes + ", subMarks=" + subMarks + "]";
	}

}
