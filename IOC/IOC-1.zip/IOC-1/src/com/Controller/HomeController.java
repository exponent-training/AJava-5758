package com.Controller;

public class HomeController {

	public static void main(String[] args) {

//		core Container -> beanfactory(I) -> XmlBeanFactory
//	    read xml X , read single at a time.

//		Resource resource = new ClassPathResource("beans.xml");

//		BeanFactory bf = new XmlBeanFactory(resource);

//		Student student = (Student) bf.getBean("stu");

//		student.m1();

		// J2ee Container -> ApplicationContext

//		ApplicationContext apc = new ClassPathXmlApplicationContext("beans.xml");
////		Student st = (Student) apc.getBean("stu");
//		st.m1();

	}

}
