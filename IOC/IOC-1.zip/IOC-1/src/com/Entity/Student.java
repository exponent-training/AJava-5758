package com.Entity;

public class Student {

	Student() {
		System.out.println("Constructor :: Called");
	}

	public void m1() {
		System.out.println("Student Class :: M1()");
	}
}
