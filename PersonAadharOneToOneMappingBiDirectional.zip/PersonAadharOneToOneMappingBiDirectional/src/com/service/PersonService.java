package com.service;

public interface PersonService {
	
	public void addPersonWithaadhar();
	
	public void getPersonOnly();
	
	public void getAadharcardOnly();
	
	public void updateAadaharcarddetailsOnlyUsingPid();
	
	public void deleteAadaharcarddetailsOnlyUsingPid();
	
	public void getallPersonOnly();
	
	public void getallAadharOnly();
	
	public void deletePersondetailsOnlyUsingPid();
	
	public void getPersonOnlyUsindAid();
	
	public void getAadharOnlyUsindAid();
	
	public void updatePersonOnlyUsindAid();
	
	public void updateAdharOnlyUsindAid();
	
	public void deleteAdharOnlyUsindAid();
	
	public void addAadharDetailsOnly();
	
	public void addExistingAadharToPerson();
	
//	public void deleteAdharOnlyUsindPid();

}
