package com.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.entity.Aadharcard;
import com.entity.Person;
import com.util.HibernateUtil;

public class PersonServiceImpl implements PersonService {

	Scanner sc = new Scanner(System.in);

	@Override
	public void addPersonWithaadhar() {

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		Person p = new Person();

		System.out.println("Enter person name:");
		p.setName(sc.next());

		System.out.println("Enter person address:");
		p.setAddress(sc.next());

		Aadharcard adhar = new Aadharcard();
		System.out.println("Enter person aadharcardno. :");
		adhar.setAadharno(sc.next());

		p.setAadhar(adhar);
		adhar.setPerson(p);

		session.save(p);
		session.beginTransaction().commit();
		System.out.println("saved successfully!!");

	}

	@Override
	public void getPersonOnly() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		/*
		 * Query<Object[]>
		 * query=session.createQuery("select pid,name,address from Person");
		 * 
		 * List<Object[]> pList = query.getResultList();
		 * 
		 * for (Object[] pidnameaddress : pList) {
		 * System.out.println(Arrays.toString(pidnameaddress)); }
		 */

		System.out.println("Enter pid whose details you want to display:");

		Person person = session.get(Person.class, sc.nextInt());

		System.out.println("Person Details:");
		System.out.println(person.getPid());
		System.out.println(person.getName());
		System.out.println(person.getAddress());

	}

	@Override
	public void getAadharcardOnly() {

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		System.out.println("Enter pid whose aadharcard details you want to display:");

		Person person = session.get(Person.class, sc.nextInt());

		System.out.println("aadharcard Details:");
		System.out.println(person.getAadhar().getAadharid());
		System.out.println(person.getName());
		System.out.println(person.getAadhar().getAadharno());

	}

	@Override
	public void updateAadaharcarddetailsOnlyUsingPid() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		System.out.println("Enter pid whose aadharcard details you want to update:");

		Person person = session.get(Person.class, sc.nextInt());

		if (person != null) {
			Aadharcard updateAdhar = person.getAadhar();

			System.out.println("enter updated aadharcard no:");
			String updatedAadharNo = sc.next();

			updateAdhar.setAadharno(updatedAadharNo);

			// person.setAadhar(updateAdhar);
			session.update(person);
			session.beginTransaction().commit();

			System.out.println("updated successfully!!");
		} else {
			System.out.println("invalid person details");
		}
	}

	@Override
	public void deleteAadaharcarddetailsOnlyUsingPid() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		System.out.println("Enter pid whose aadharcard details you want to delete:");

		Person person = session.get(Person.class, sc.nextInt());

		if (person != null) {
			Aadharcard aadhar = person.getAadhar();
			person.setAadhar(null);
			aadhar.setPerson(null);
			session.update(person);
			session.delete(aadhar);
			session.beginTransaction().commit();
			System.out.println("deleted successfully!!");
		} else {
			System.out.println("invalid person details");
		}

	}

	@Override
	public void getallPersonOnly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getallAadharOnly() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePersondetailsOnlyUsingPid() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getPersonOnlyUsindAid() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getAadharOnlyUsindAid() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updatePersonOnlyUsindAid() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateAdharOnlyUsindAid() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAdharOnlyUsindAid() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addExistingAadharToPerson() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		System.out.println("Enter pid to exsting aadhar mappped:");

		Person person = session.get(Person.class, sc.nextInt());

		if (person != null) {
			Aadharcard aadhar = person.getAadhar();
			if (aadhar == null) {
				System.out.println("Enter aid to exsting person mappped:");
				Aadharcard ad =session.get(Aadharcard.class, sc.nextInt());
				Person pr =ad.getPerson();
				if (pr==null) {
					person.setAadhar(ad);
					ad.setPerson(person);
					session.update(person);
					session.beginTransaction().commit();
				}
			}
			
			//session.beginTransaction().commit();
			System.out.println("updated successfully!!");
		} else {
			System.out.println("invalid person details");
		}

		
	}

	@Override
	public void addAadharDetailsOnly() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		System.out.println("Enter no. of aadhar details you want to add: ");
		
		int n = sc.nextInt();
		
		List<Aadharcard> aadharList = new ArrayList<Aadharcard>();
		
		for(int i = 1;i<=n;i++) {
			
			Aadharcard aadhar = new Aadharcard();
			System.out.println("Enter aadharcard no: ");
			aadhar.setAadharno(sc.next());
			aadharList.add(aadhar);
		}
		for (Aadharcard aadharcard : aadharList) {
			session.save(aadharcard);
		}
		
		System.out.println("success!!");
		
	}

}
