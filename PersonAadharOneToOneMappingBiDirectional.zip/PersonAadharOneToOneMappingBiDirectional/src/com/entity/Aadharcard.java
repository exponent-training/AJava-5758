package com.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Aadharcard {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int aadharid;
	
	private String aadharno;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Person person;

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public int getAadharid() {
		return aadharid;
	}

	public void setAadharid(int aadharid) {
		this.aadharid = aadharid;
	}

	public String getAadharno() {
		return aadharno;
	}

	public void setAadharno(String aadharno) {
		this.aadharno = aadharno;
	}

	
	
	
}
