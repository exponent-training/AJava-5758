package com.controller;

import com.service.PersonService;
import com.service.PersonServiceImpl;

public class PersonController {
	
	public static void main(String[] args) {
		
		PersonService ps = new PersonServiceImpl();
		
		//ps.addPersonWithaadhar();
		
		//ps.getPersonOnly();
		
		//ps.getAadharcardOnly();
		
		//ps.updateAadaharcarddetailsOnlyUsingPid();
		
		//ps.deleteAadaharcarddetailsOnlyUsingPid();
		
		//ps.addAadharDetailsOnly();
		
		ps.addExistingAadharToPerson();
	}

}
