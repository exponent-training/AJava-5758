package com.Service;

public interface PersonAdharService {

	public void addPersonWithAdhar();

	public void getAllPersonOnly();

	public void getAllAhdarOnly();

	public void getPersonOnlyUsingPID();

	public void getAdharOnlyUsingPID();

	public void updatePersonOnlyUsingPID();

	public void updateAdharOnlyUsingPID();

	public void deletePersoOnlyUsingPID();

	public void deleteAdharOnlyUsingPID();

	public void getPersonOnlyUsingAID();

	public void getAdharOnlyUsingAID();

	public void updatePersonOnlyUsingAID();

	public void updateAdharOnlyUsingAID();

	public void deletePersoOnlyUsingAID();

	public void deleteAdharOnlyUsingAID();

}
