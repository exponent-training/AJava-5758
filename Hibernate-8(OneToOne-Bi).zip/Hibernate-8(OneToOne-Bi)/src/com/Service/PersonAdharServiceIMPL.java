package com.Service;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import com.Config.Hibernatutil;
import com.Entity.Adhar;
import com.Entity.Person;

public class PersonAdharServiceIMPL implements PersonAdharService {

	SessionFactory sf = Hibernatutil.getsessionFactory();

	@Override
	public void addPersonWithAdhar() {

		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		Person p = new Person();
		System.out.println("Enter the Person Name");
		p.setPname(sc.next());
		System.out.println("Enter the Person Address :- ");
		p.setPaddress(sc.next());
		Adhar ad = new Adhar();
		System.out.println("Enter the Adhar Number :- ");
		ad.setAdharNumber(sc.next());

		p.setAdhar(ad);
		ad.setPerson(p);

		s.save(p);
		s.beginTransaction().commit();
		System.out.println("Person added");

	}

	@Override
	public void getAllPersonOnly() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getAllAhdarOnly() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getPersonOnlyUsingPID() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Person ID :- ");
		Person person = s.get(Person.class, sc.nextInt());
		if (person != null) {

			System.out.println(person.getPid());
			System.out.println(person.getPname());
			System.out.println(person.getPaddress());

		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void getAdharOnlyUsingPID() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Person ID :- ");
		Person person = s.get(Person.class, sc.nextInt());
		if (person != null) {

			System.out.println(person.getAdhar());

		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void updatePersonOnlyUsingPID() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Person ID :- ");
		Person person = s.get(Person.class, sc.nextInt());
		if (person != null) {

			System.out.println("Enter the Person New Name :- ");
			person.setPname(sc.next());

			System.out.println("Enter the New ADdress :- ");
			person.setPaddress(sc.next());

			s.update(person);
			s.beginTransaction().commit();
			System.out.println("Person Upadted");

		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void updateAdharOnlyUsingPID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deletePersoOnlyUsingPID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAdharOnlyUsingPID() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Person ID :- ");
		Person person = s.get(Person.class, sc.nextInt());
		if (person != null) {

//			person.setAdhar(null);
//			Adhar adhar = person.getAdhar();
//			adhar.setPerson(null);

			Adhar adhar = person.getAdhar();
			adhar.setPerson(null);
			person.setAdhar(null);
			s.update(person);
			s.delete(adhar);
			s.beginTransaction().commit();
			System.out.println("adhar deleted");

		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void getPersonOnlyUsingAID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getAdharOnlyUsingAID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updatePersonOnlyUsingAID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAdharOnlyUsingAID() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deletePersoOnlyUsingAID() {
		Session s = sf.openSession();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Adhar ID :- ");
		Adhar ad = s.get(Adhar.class, sc.nextInt());
		if (ad != null) {

			Person person = ad.getPerson();
			person.setAdhar(null);
			ad.setPerson(null);
			s.update(ad);
			s.delete(person);

			s.beginTransaction().commit();
			System.out.println("Person deleted");

		} else {
			System.out.println("Invalid ID");
		}

	}

	@Override
	public void deleteAdharOnlyUsingAID() {
		// TODO Auto-generated method stub

	}

}
