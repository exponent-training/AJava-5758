package com.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.entity.Employees;
import com.util.HibernateUtil;

public class EmployeeServiceImpl implements EmployeeService {

	@Override
	public void addEmployees() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		Employees e1 = new Employees();
		e1.setEname("Raj");
		e1.setEmail("raj@gmail.com");
		e1.setSalary(50000);

		Employees e2 = new Employees();
		e2.setEname("Priya");
		e2.setEmail("priya@gmail.com");
		e2.setSalary(67000);

		Employees e3 = new Employees();
		e3.setEname("Guari");
		e3.setEmail("guari@yahoo.com");
		e3.setSalary(78000);

		Employees e4 = new Employees();
		e4.setEname("Suraj");
		e4.setEmail("suraj@yahoo.com");
		e4.setSalary(59000);

		Employees e5 = new Employees();
		e5.setEname("Saurav");
		e5.setEmail("Saurav@gmail.com");
		e5.setSalary(39000);

		List<Employees> list = new ArrayList<Employees>();

		Collections.addAll(list, e1, e2, e3, e4, e5);

		for (Employees employees : list) {
			session.save(employees);
		}
		session.beginTransaction().commit();
		System.out.println("Success!!");
	}

	@Override
	public void fetchEmployeeDetailByNamedQuery() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();
		
		Query<Employees> query =session.getNamedQuery("fetchAllEmployees");
		List<Employees> listOfEmps = query.getResultList();
		
		System.out.println("Employees details: ");
		for (Employees employees : listOfEmps) {
			System.out.println(employees);
		}

	}

	@Override
	public void updateEmployeeDetailByNamedQuery() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();
		
		Query query=session.getNamedQuery("updateEmployeeDetails");
		
		Transaction tx = session.beginTransaction();
		
		query.setParameter("esalary", 90000.125);
		query.setParameter("id", 1);
		query.executeUpdate();
		
		tx.commit();
		System.out.println("Updated successfully!!");
	}

	@Override
	public void fetchEmployeeDetailByNamedNativeQuery() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();
		
		Query<Employees> query =session.getNamedNativeQuery("fetchallEmployeesByNativequery");
		List<Employees> listOfEmps = query.getResultList();
		
		System.out.println("Employees details: ");
		for (Employees employees : listOfEmps) {
			System.out.println(employees);
		}
		
	}

	@Override
	public void deleteEmployeeByIdNativequery() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();
		
		Query query=session.getNamedNativeQuery("deleteEmployeeByIdNativequery");
		
		Transaction tx = session.beginTransaction();
		
		query.setParameter(1, 5);
		query.executeUpdate();
		
		tx.commit();
		System.out.println("deleted successfully!!");
		
		
	}

}










