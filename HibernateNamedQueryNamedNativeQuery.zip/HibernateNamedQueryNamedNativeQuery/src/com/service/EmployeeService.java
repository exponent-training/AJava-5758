package com.service;

public interface EmployeeService {
	
	public void addEmployees();
	
	public void fetchEmployeeDetailByNamedQuery();
	
	public void updateEmployeeDetailByNamedQuery();

	public void fetchEmployeeDetailByNamedNativeQuery();
	
	public void deleteEmployeeByIdNativequery();
}
