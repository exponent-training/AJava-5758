package com.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

//Perform By NamedQuery: HW --> 1) fetch name & salary 2) fetch employees having gmail as their email address
//HW --> print salaries in descending order
@Entity
@NamedQueries({
	@NamedQuery(name = "fetchAllEmployees" , query = "from Employees"),
	@NamedQuery(name = "updateEmployeeDetails", query = "update Employees set salary=:esalary where eid=:id")
})
@NamedNativeQueries({
	@NamedNativeQuery(name = "fetchallEmployeesByNativequery", query = "select * from employees", resultClass = Employees.class),
	@NamedNativeQuery(name = "deleteEmployeeByIdNativequery", query = "delete from employees where eid=?")
})
public class Employees {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int eid;
	
	private String ename;
	
	private String email;
	
	private double salary;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employees [eid=" + eid + ", ename=" + ename + ", email=" + email + ", salary=" + salary + "]";
	}
	
	

}
