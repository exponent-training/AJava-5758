package com.controller;

import com.criteriabuilder.EmployeeServiceCB;
import com.criteriabuilder.EmployeeServiceImplCriteriaBuilder;
import com.service.EmployeeService;
import com.service.EmployeeServiceImpl;

public class EmployeeController {
	
	public static void main(String[] args) {
		
		EmployeeService emp = new EmployeeServiceImpl();
		
		//emp.addEmployees();
		
		//emp.fetchEmployeeDetailByNamedQuery();
		
		//emp.updateEmployeeDetailByNamedQuery();
		
		System.out.println("------------------------------------------");
		
		//emp.fetchEmployeeDetailByNamedNativeQuery();
		
		//emp.deleteEmployeeByIdNativequery();
		
		EmployeeServiceCB ecb = new EmployeeServiceImplCriteriaBuilder();
		
		//ecb.fetchAllEmployees();
		
		//ecb.getMaxSalaryEmployees();
		
		ecb.updateEmployeeDetails();
	}

}
