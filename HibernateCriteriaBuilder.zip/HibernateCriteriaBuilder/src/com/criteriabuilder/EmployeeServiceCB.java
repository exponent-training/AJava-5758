package com.criteriabuilder;

public interface EmployeeServiceCB {

	public void fetchAllEmployees();
	
	public void getMaxSalaryEmployees();
	
	public void updateEmployeeDetails();
}
