package com.criteriabuilder;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.entity.Employees;
import com.util.HibernateUtil;

public class EmployeeServiceImplCriteriaBuilder implements EmployeeServiceCB {

	@Override
	public void fetchAllEmployees() {

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		// select * from employees;
		// from employees

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<Employees> criteriaQuery = builder.createQuery(Employees.class);

		Root<Employees> root = criteriaQuery.from(Employees.class);

		criteriaQuery.select(root);
		// select * from employees;

		Query<Employees> query = session.createQuery(criteriaQuery);

		List<Employees> empList = query.getResultList();

		System.out.println("employees details: ");
		for (Employees employees : empList) {
			System.out.println(employees);
		}

	}

	@Override
	public void getMaxSalaryEmployees() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		// select max(salary) from Employees;

		CriteriaBuilder builder = session.getCriteriaBuilder();

		CriteriaQuery<?> criteriaQuery = builder.createQuery(Employees.class);

		Root<?> root = criteriaQuery.from(Employees.class);

		criteriaQuery.select(builder.max(root.get("salary"))); // select max(salary) from employees;

		Query<?> query = session.createQuery(criteriaQuery);

		Double maxSalary = (Double) query.getSingleResult();

		System.out.println("Maximum salary = " + maxSalary);

	}

	@Override
	public void updateEmployeeDetails() {

		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session session = sf.openSession();

		// select max(salary) from Employees;

		CriteriaBuilder builder = session.getCriteriaBuilder();

		Transaction tx = session.beginTransaction();

		CriteriaUpdate<Employees> updateQuery = builder.createCriteriaUpdate(Employees.class);

		Root<Employees> root = updateQuery.from(Employees.class);

		// update employees set salary = 85000.34 where id = 3;

		updateQuery.set("salary", 85000.34);
		updateQuery.where(builder.equal(root.get("eid"), 3));

		Query query = session.createQuery(updateQuery);

		query.executeUpdate();

		tx.commit();

		System.out.println("Success!!");

	}

}
