package com.UserDAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.User;

@Repository
public class UserDaoIMPL implements UserDaoInterface {

	@Autowired
	private SessionFactory sf;

	@Override
	public void registerInDao(User user) {

		System.out.println("I amin Dao Layer");
		Session s = sf.openSession();
		s.save(user);
		s.beginTransaction().commit();
		System.out.println("User Save");

	}
}
