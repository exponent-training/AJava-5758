package com.UserDAO;

import com.Entity.User;

public interface UserDaoInterface {

	void registerInDao(User user);

}
