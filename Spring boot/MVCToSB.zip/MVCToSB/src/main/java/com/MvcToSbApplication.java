package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@SpringBootApplication(exclude = {DriverManagerDataSource.class})
public class MvcToSbApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(MvcToSbApplication.class, args);
		System.out.println(context.getBeanDefinitionCount());

	}

}
