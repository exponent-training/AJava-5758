package com.UserService;

import com.Entity.User;

public interface UserServiceInteface {

	void registerUser(User user);

}
