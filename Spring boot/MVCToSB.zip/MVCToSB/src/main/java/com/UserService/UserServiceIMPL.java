package com.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Entity.User;
import com.UserDAO.UserDaoInterface;

@Service
public class UserServiceIMPL implements UserServiceInteface {

	@Autowired
	private UserDaoInterface ud;

	@Override
	public void registerUser(User user) {

		System.out.println("I am in Service Layer");

		ud.registerInDao(user);

	}

}
