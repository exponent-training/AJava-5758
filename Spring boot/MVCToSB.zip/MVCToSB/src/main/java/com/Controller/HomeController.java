package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Entity.User;
import com.UserService.UserServiceInteface;

@Controller
public class HomeController {

	@Autowired
	private UserServiceInteface us;

	@RequestMapping("/")
	public String getRequest() {

		return "index";

	}

	@RequestMapping("/reg")
	public String getRegisterRequest(@ModelAttribute User user) {

		System.out.println("---I am in Controller----");
		System.out.println(user);

		us.registerUser(user);

		return "index";
	}

}
